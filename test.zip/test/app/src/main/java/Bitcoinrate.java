/**
 * Created by macstudent on 2018-04-12.
 */

public class Bitcoinrate {
    String price;
    String dated;
    String currencycode;

    Bitcoinrate()
    {


    }
    Bitcoinrate(String p, String d, String c)
    {
        this.price =p;
        this.dated = d;
        this.currencycode =c;

    }


}
