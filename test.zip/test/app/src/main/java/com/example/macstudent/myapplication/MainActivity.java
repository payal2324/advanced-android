package com.example.macstudent.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {
EditText editText1;
RequestQueue myRequestQueue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editText1 = (EditText)findViewById(R.id.data);
        if (myRequestQueue == null) {
            myRequestQueue = Volley.newRequestQueue(getApplicationContext());
        }
    }

    public void btnclicked(View view) {
        Log.d("start" ,"hello");

        String currency = editText1.getText().toString();
        Log.d("currency", currency.toString());

        String url = "https://api.coindesk.com/v1/bpi/currentprice.json";

        JsonObjectRequest jsObjRequest =
                new JsonObjectRequest(
                        Request.Method.GET,
                        url,
                        null,
                        new Response.Listener<JSONObject>() {
                            @Override
                            public void onResponse(JSONObject response) {
                                // Check that you went to the correct website
                                // by printing out the response
                                Log.d("hiii this is dicionary", response.toString());

                                try {
                                    String bpi = response.getJSONObject("bpi").toString();

                                    Log.d("getting bpi", response.getJSONObject("bpi").toString());

                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }


                            }
                        }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // TODO Auto-generated method stub
                        Log.e("" , error.toString());
                    }
                });
        myRequestQueue.add(jsObjRequest);


    }
}
