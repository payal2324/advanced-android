package com.example.user.maplocation;

import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.util.Log;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;

import com.google.android.gms.maps.model.PolylineOptions;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;

    LatLng loc1, loc2, loc3, loc4, midpoint1, midpoint2, prisonright1, prisonright2, prisonleft1, prisonleft2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_maps);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
        loc1 = new LatLng(43.773534, -79.335208);
        loc2 = new LatLng(43.773258, -79.335208);
        loc3 = new LatLng(43.773258, -79.335608);
        loc4 = new LatLng(43.773534, -79.335608);

       double midpx = ((loc4.latitude - loc3.latitude) / 2) + loc3.latitude;  // same for midp2x
        Log.e("Location", "onCreate: Latitude" + midpx);
       double midp1y = loc3.longitude;

       double midp2y = loc1.longitude;
        midpoint1 = new LatLng(midpx,midp1y);
                midpoint2 = new LatLng(midpx,midp2y);
// prison right lat long settting
        double x1 = loc1.latitude;
        Log.d("hello", "onCreate: x1  " + x1);
        prisonright1 = new LatLng(((Double) x1), -79.335108);
        Log.d("hello", "onCreate: prison1  " + prisonright1.latitude +  "   huh  " + prisonright1.longitude);
        double x2 = midpoint2.latitude;
        Log.d("hello", "onCreate: x2  " + x2);
        prisonright2 = new LatLng(x2,-79.335108);

// prison left lat long settings
        double x3 = midp1y - 0.000100;
        prisonleft1 = new LatLng(midpx, x3);

double x4 = loc3.longitude - 0.000100;
prisonleft2 = new LatLng(loc3.latitude,x4);




    }


    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        // markers
//        mMap.addMarker(new MarkerOptions().position(loc1).title("Loc 1"));
//        mMap.addMarker(new MarkerOptions().position(loc2).title("Loc 2"));
//        mMap.addMarker(new MarkerOptions().position(loc3).title("Loc 3"));
//        mMap.addMarker(new MarkerOptions().position(loc4).title("Loc 4"));
//        mMap.addMarker(new MarkerOptions().position(midpoint1).title("midpoint1"));
//        mMap.addMarker(new MarkerOptions().position(midpoint2).title("midpoint2"));
//
//        mMap.addMarker(new MarkerOptions().position(prisonright1).title("prisonright1"));
//        mMap.addMarker(new MarkerOptions().position(prisonright2).title("prisonright2"));
//        mMap.addMarker(new MarkerOptions().position(prisonleft1).title("prisonleft1"));
//        mMap.addMarker(new MarkerOptions().position(prisonleft2).title("prisonleft2"));



        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(loc1,18f));

        // Add a marker in Sydney and move the camera
      //  LatLng sydney = new LatLng(-34, 151);
     //   mMap.addMarker(new MarkerOptions().position(sydney).title("Marker in Sydney"));
      //  mMap.moveCamera(CameraUpdateFactory.newLatLng(sydney));

        mMap.addPolyline(
                new PolylineOptions().add(
                        loc1,
                        loc2
                ).width(10).color(Color.BLUE).geodesic(true)
        );
        mMap.addPolyline(
                new PolylineOptions().add(
                        loc2,
                        loc3
                ).width(10).color(Color.BLUE).geodesic(true)
        );
        mMap.addPolyline(
                new PolylineOptions().add(
                        loc3,
                        loc4
                ).width(10).color(Color.BLUE).geodesic(true)
        );
        mMap.addPolyline(
                new PolylineOptions().add(
                        loc4,
                        loc1
                ).width(10).color(Color.BLUE).geodesic(true)
        );

        mMap.addPolyline(
                new PolylineOptions().add(
                        midpoint1,
                        midpoint2
                ).width(10).color(Color.RED).geodesic(true)
        );


        // for right prison
        mMap.addPolyline(
                new PolylineOptions().add(
                        loc1,
                        prisonright1
                ).width(10).color(Color.BLACK).geodesic(true)
        );
        mMap.addPolyline(
                new PolylineOptions().add(
                        prisonright1,
                        prisonright2
                ).width(10).color(Color.BLACK).geodesic(true)
        );
        mMap.addPolyline(
                new PolylineOptions().add(
                        prisonright2,
                        midpoint2
                ).width(10).color(Color.BLACK).geodesic(true)
        );

            // for left prison
        mMap.addPolyline(
                new PolylineOptions().add(
                        midpoint1,
                        prisonleft1
                ).width(10).color(Color.BLACK).geodesic(true)
        );
        mMap.addPolyline(
                new PolylineOptions().add(
                        prisonleft1,
                        prisonleft2
                ).width(10).color(Color.BLACK).geodesic(true)
        );
        mMap.addPolyline(
                new PolylineOptions().add(
                        prisonleft2,
                        loc3
                ).width(10).color(Color.BLACK).geodesic(true)
        );




    }

//43.8085359,-79.3243028

    }



