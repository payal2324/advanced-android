package com.example.macstudent.speechtotext;

import android.Manifest;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.speech.RecognizerIntent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.karumi.dexter.Dexter;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionDeniedResponse;
import com.karumi.dexter.listener.PermissionGrantedResponse;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.single.PermissionListener;

import java.util.List;

public class MainActivity extends AppCompatActivity {
    TextView t;
    Button b;
    private final int SPEECH_REQUEST_CODE = 500; // take any number
        // permission listener variable
    PermissionListener phonePermissionListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        t = (TextView) findViewById(R.id.data1);
        b = (Button) findViewById(R.id.translate);
        createPermissionListener();

        Dexter.withActivity(this)
                .withPermission(Manifest.permission.CALL_PHONE)
                .withListener(phonePermissionListener)
                .check();

    }

    public void createPermissionListener(){
        if(phonePermissionListener == null){
            phonePermissionListener = new PermissionListener() {
                @Override
                public void onPermissionGranted(PermissionGrantedResponse response) {
                        // do nothing
                }

                @Override
                public void onPermissionDenied(PermissionDeniedResponse response) {
                    t.setText("App needs permission to work properly!");
                }

                @Override
                public void onPermissionRationaleShouldBeShown(PermissionRequest permission, PermissionToken token) {
                    token.continuePermissionRequest();

                }
            };
        }
    }


    public void dialPhonenumber(String number){
        //1 get the phone number and parse into something google understands
            String phoneNumber = "tel:" + number;    // tel automatically opens phone dialer..



        //2 make the phone call
        //a. create a phone dial intent
            Intent dialerIntent = new Intent(Intent.ACTION_CALL);

        // b. configure the intent
                dialerIntent.setData(Uri.parse(phoneNumber));

        // c. start the intent
             startActivity(dialerIntent);


    }



    public void buttonPressed(View view) {
        // put the code for speech to text in here
        //a.You : Start the google  create intent  box start ho jana .

        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);

        // b. optional configure the intent
        // SETUP NONSENSE: the next two lines are all setup nonsense

        // to tell what language you are speaking and speak line or words ...
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, "pt-br");

        // optional:  configure the message on the microphone popup box
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "What color is the sky?");

        // check kro k phone ch feature hai k nhi
        //c. and start the intent
        try {

            // 2 . Google : llisten and wait for person to finish talking
            //3. Google : automatically translates their speech to text
            // show the popup box
            startActivityForResult(intent, SPEECH_REQUEST_CODE);     //c. start the intent
        } catch (ActivityNotFoundException a) {
            // Sometimes you are using a phone that doesn't have speech to text functions
            // If this happens, then show error message.
            String msg = "Your phone doesn't support speech to text.";
            Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_SHORT).show();
        }


        // startActivityForResult(intent,SPEECH_REQUEST_CODE );


    }




    //4
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == SPEECH_REQUEST_CODE) {
            if (resultCode == RESULT_OK) {
            // logic get the text and do something with it
                // get
                List<String> results = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                String answer = results.get(0); // get first thing out

                // show
                t.setText("You said :  " + answer);
                dialPhonenumber(answer);

            }

        }
    }
}