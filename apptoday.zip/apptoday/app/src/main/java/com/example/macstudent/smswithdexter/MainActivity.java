package com.example.macstudent.smswithdexter;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import com.karumi.dexter.Dexter;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionDeniedResponse;
import com.karumi.dexter.listener.PermissionGrantedResponse;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.single.PermissionListener;

import java.util.jar.Manifest;

public class MainActivity extends AppCompatActivity {
    public final String TAG = "JENELLE";
    PermissionListener smsPermissionListener;  // dexter class  PermissionListener to allow or deny permissions.

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        createPermissionListener();
    }


    // setup your permissions

    public void createPermissionListener()
    {
        //check if permission listener is null
        if(smsPermissionListener == null)
        {
            //give the variable a value

            smsPermissionListener = new PermissionListener() {
                @Override
                public void onPermissionGranted(PermissionGrantedResponse response) {

                  // person pressed allow


                    // send the sms
                    SmsManager smsManager = SmsManager.getDefault();
                    smsManager.sendTextMessage("6477207531",null, "the test is thursday", null, null);

                    // show a message to the user that the message
                    TextView t = (TextView) findViewById(R.id.statusMessage);
                    t.setText("Message sent!");
                }

                @Override
                public void onPermissionDenied(PermissionDeniedResponse response) {

                  // person press deny

                }

                @Override
                public void onPermissionRationaleShouldBeShown(PermissionRequest permission, PermissionToken token) {
                // if current permission is set to deny...

                    token.continuePermissionRequest();  // github code  https://github.com/karumi/dexter

                }
            };

        }


        // if yes then give it a value



        // otherwise do something

    }




    public void sendButtonPressed(View view) {
        Log.d(TAG, "sending a sms");

        // ask for permission


        /*Dexter.withActivity(activity)
			.withPermission(permission)
			.withListener(listener)   listener is call back what they do if we allow something or deny... its all logic
			.check();

*/
        Dexter.withActivity(this)
                .withPermission(android.Manifest.permission.SEND_SMS)
                .withListener(smsPermissionListener)
                .check();

      //  createPermissionListener();

//        // send the sms
//        SmsManager smsManager = SmsManager.getDefault();
//        smsManager.sendTextMessage("6477207531",null, "the test is thursday", null, null);
//
//        // show a message to the user that the message
//        TextView t = (TextView) findViewById(R.id.statusMessage);
//        t.setText("Message sent!");
    }



}
