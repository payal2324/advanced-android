package com.example.macstudent.myapplication;

/**
 * Created by macstudent on 2018-04-05.
 */

public class Person {
    public String name;
    public String age;

    public Person()
    {

    }
    public Person(String n, String a)
    {
        this.name = n;
        this.age =a;

    }
}
