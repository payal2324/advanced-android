package com.example.macstudent.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class MainActivity extends AppCompatActivity {

    //1 create some database variables

    FirebaseDatabase db; // 2
    DatabaseReference rootnode;  // 3
    // 3 androiidstudio..preferences editor auto import check auto import

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //4 setup the database

        db = FirebaseDatabase.getInstance() ;
        //4 grabs actual connection to the database

        rootnode = db.getReference(); // 5 like your local storage



    }






    // 6 activity.xml ch jao ya userinterface bnao

    public void addclick(View v)   // when we click on button this function fires
    {
        // add something to the database
      //  rootnode.setValue("milan");

        EditText ename =(EditText) findViewById(R.id.name);
        EditText eage =(EditText) findViewById(R.id.age);

String name = ename.getText().toString();
String age = eage.getText().toString();

      //  rootnode.setValue(name);
      //  rootnode.child("table").setValue(name);
      //  rootnode.child("email").setValue(name);     // new value add hundi ya firebase ch awesome work
      //  rootnode.child("password").setValue("payal123");
      //  e.setText("");

        // now try adding object   select main activity file add a java class

        Person p = new Person(name , age);
        rootnode.push().setValue(p);

        // aagr new filed add krange ta oh v hojayega database ch add
      //  Person p1 = new Person("Anna","24");
        //rootnode.push().setValue(p1);  // push() used to add stuff ..
        ename.setText("");
        eage.setText("");
    }
}
