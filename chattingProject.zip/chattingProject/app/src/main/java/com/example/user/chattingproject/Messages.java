package com.example.user.chattingproject;

/**
 * Created by USER on 4/15/2018.
 */

public class Messages {

    public String sender;
    public String message;
    public String date;

    Messages(){

    }
    public Messages(String sender, String message, String date) {
        this.sender = sender;
        this.message = message;
        this.date = date;
    }
}
