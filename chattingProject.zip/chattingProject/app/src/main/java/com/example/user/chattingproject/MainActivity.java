package com.example.user.chattingproject;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.view.View;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.SimpleDateFormat;
import java.util.Date;

public class MainActivity extends AppCompatActivity {
FirebaseDatabase database;
DatabaseReference root;
    Button btnSend;
    EditText data;
    TextView showData;
ChildEventListener bacha;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnSend = (Button)findViewById(R.id.btnSend);
        data = (EditText)findViewById(R.id.data);
        showData =(TextView)findViewById(R.id.showData);

        database = FirebaseDatabase.getInstance();
        root = database.getReference();


        btnSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d("hello ","button clicked");
                Date d = new Date();
                SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yy");
                String date = sdf.format(d);

                String enteredData = String.valueOf(data.getText());

                Messages msg = new Messages("Payal",enteredData,date);
                root.child("messages").push().setValue(msg);
                Log.d("end","ok ");

            }
        });

        eventRelated();


         /*
        Messages msg = new Messages("Payal","hello Jassi, How are you?",date);
        Log.d("start","hii ");
        Toast.makeText(this,"ulll",Toast.LENGTH_SHORT).show();
        root.child("messages").push().setValue(msg);
        Toast.makeText(this," done",Toast.LENGTH_SHORT).show();
        Log.d("end","ok ");

        */
    }

public void eventRelated(){
        bacha = new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                Messages m = dataSnapshot.getValue(Messages.class);
                String txt = m.sender + ": " + m.message + " says: " + m.date + "\n";

                // 2. show this item in the textview
                showData.append(txt);


            }

            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String s) {
                Messages m = dataSnapshot.getValue(Messages.class);
                String txt = m.sender + ": " + m.message + ": on " + m.date + "\n";
                showData.setText(txt);
            }

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        };
root.child("messages").addChildEventListener(bacha);

}

}
